<?php get_header(); # show header ?>

<?php it_get_template_part('post-loop'); # post loop ?>

<?php get_footer(); # show footer ?>