<?php
// Template Name: Minisite Directory
?>
<?php get_header(); # show header ?>

<?php it_get_template_part('post-loop'); # page content ?>

<?php get_footer(); # show footer ?>