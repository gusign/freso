<?php
// Template Name: Author Listing
?>
<?php get_header(); # show header ?>

<?php it_get_template_part('page-content'); # page content ?>

<?php get_footer(); # show footer ?>